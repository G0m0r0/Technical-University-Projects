﻿namespace p1
{
    class StartUp
    {
        static void Main(string[] args)
        {
            d2.Engine engin = new d2.Engine();
            engin.Run(args);
        }        
    }
}
