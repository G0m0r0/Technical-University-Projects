﻿namespace BankAccountManager.Models.Person.Contracts
{
    public interface IUser
    {
        string Username { get; }
        string Password { get; }
    }
}
