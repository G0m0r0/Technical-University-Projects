﻿namespace BankAccountManager.Models.Cards.Contracts
{
    public interface ICard
    {
    }
}
