﻿namespace BankAccountManager.Models.Cards.Contracts
{
    class IStatusCard
    {
    }
}
