﻿namespace BankAccountManager.Models.Cards
{
    using Models.Cards.Contracts;
    public class Card : ICard
    {
    }
}
