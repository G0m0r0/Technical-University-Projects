﻿namespace BankAccountManager.IO.Contracts
{
    public interface IWFMessageBox
    {
       void Show(string message);
    }
}
