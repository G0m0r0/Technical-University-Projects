﻿namespace BankAccountManager.IO.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}
