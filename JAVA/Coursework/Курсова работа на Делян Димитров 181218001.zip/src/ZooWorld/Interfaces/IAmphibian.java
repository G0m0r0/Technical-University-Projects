package ZooWorld.Interfaces;

public interface IAmphibian extends IAnimal{
	public String PreferedPlace();
}
