package ZooWorld.Interfaces;

public interface IBird extends IAnimal{
	public String PokeBirdToFly();
}
