package ZooWorld.Interfaces;

public interface IMammal extends IAnimal{
	public String PetAnimal();
	public String IsMammalBaby();
	public String Sound();
}
