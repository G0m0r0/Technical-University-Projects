package ZooWorld;

public abstract class Fish extends Animal {

	public Fish(String name, int bornYear) {
		super(name, bornYear);
		// TODO Auto-generated constructor stub
	}

}
