package ZooWorld.Animals;

import ZooWorld.Reptile;

public class Lizzard extends Reptile{

	public Lizzard(String name, int bornYear) {
		super(name, bornYear);
		// TODO Auto-generated constructor stub
	}

}
