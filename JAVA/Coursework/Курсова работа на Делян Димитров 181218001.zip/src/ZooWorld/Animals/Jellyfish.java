package ZooWorld.Animals;

import ZooWorld.Fish;

public class Jellyfish extends Fish{

	public Jellyfish(String name, int bornYear) {
		super(name, bornYear);
		// TODO Auto-generated constructor stub
	}

}
