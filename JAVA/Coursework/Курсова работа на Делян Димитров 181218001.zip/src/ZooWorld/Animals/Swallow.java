package ZooWorld.Animals;

import ZooWorld.Animal;
import ZooWorld.Bird;

public class Swallow extends Bird{

	public Swallow(String name, int bornYear) {
		super(name, bornYear);
		// TODO Auto-generated constructor stub
	}

}
