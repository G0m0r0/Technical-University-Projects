package ZooWorld.Animals;

import ZooWorld.Amphibian;
import ZooWorld.Interfaces.IAmphibian;

public class Frog extends Amphibian implements IAmphibian{

	public Frog(String name, int bornYear,String preferedPlace) {
		super(name, bornYear, preferedPlace);
		// TODO Auto-generated constructor stub
	}

}
